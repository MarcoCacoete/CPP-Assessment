#pragma once
#include "Item.h"
#include<vector>
class ItemList
{

public:
	ItemList();

	virtual void toString()=0;
	virtual ~ItemList();

private:

};

