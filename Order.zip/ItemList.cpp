#include "ItemList.h"

ItemList::ItemList() {

	cout << "I'm the item list." << endl;
	vector<Item*> items;
}


ItemList::~ItemList()
{
}

