#pragma once
#include "Item.h"
#include<vector>

class ItemList
{
    ItemList();
    virtual string toString() const = 0;   

    virtual ~ItemList() {}


};