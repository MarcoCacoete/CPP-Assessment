#include "Order.h"


Order::Order() {

	cout << "I'm an empty order" << endl;
	vector<Item*> OrderList;

}

Order::~Order() {
	cout << "Destroyed " << "." << endl;
	
}
string Order::toString() const
{
	return string();
}



double total = 0;


void Order::add(Item* obj) {

	OrderList.push_back(obj);
}
