#pragma once

#include "ItemList.h"
#include <iostream>
#include <string>
#include<fstream>
#include <sstream>
#include <vector>
using namespace std;
class Item
{
public:
	Item();
	Item(string name,double price,int calories);

	~Item();
	string name;
	double price;
	int calories;
	virtual string toString() = 0;
private:

};

